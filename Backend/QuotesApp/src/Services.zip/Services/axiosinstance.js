import axios from "axios";

const axiosInstance = axios.create({
    baseURL:"https://15.207.249.118:7000/",
    headers:{
        // 'Content-Type': 'application/json',
        // 'Authorization':sessionStorage['jwt'] ? `Bearer `+sessionStorage['jwt'] : "",
    },
    });

export default axiosInstance;
